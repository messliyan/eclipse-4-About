package com.example.e4.filebrowser.handlers;

public class OpenEditorHandler {

}
