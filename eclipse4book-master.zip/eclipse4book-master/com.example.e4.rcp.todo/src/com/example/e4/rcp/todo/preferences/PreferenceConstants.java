package com.example.e4.rcp.todo.preferences;

public interface PreferenceConstants {
	public static final String NODEPATH = "com.example.e4.rcp.todo";
	public static final String USER_PREF_KEY = "user";
	public static final String PASSWORD_PREF_KEY = "password";
}
